Thanks for trying out PSP Revolution 0.3

PSP Revolution is based off the popular game StepMania and  is compatible
with StepMania (.SM) and Dance With Intensity (.DWI) song files. 

To install additional songs, copy them into pack folders in 
"\psp\game\pspr\songs" just as you would in StepMania

To Install, copy contents of 1.0 or 1.5 folder (depending on your firmware version)
in to your "\psp\game" folder. 

If you are using firmware 1.0/2.xx eboot, first copy the "1.0_EBOOT_ONLY\PSPR" folder
into your "\psp\game" folder on the PSP, and then you must also copy the folders out of the 
"1.5\pspr" folder. Make sure NOT to overwrite the 1.0 EBOOT.PBP

For the best music experience we recommend playing with head/earphones!

The songs included in this version are different than the songs that were included in this version, so remember to copy them into version 0.2 before you delete them if you want to keep the original songs!

---------------------------------------------------------------------------------------------
If you enjoy the game and would like treat me to a dinner or show support please feel free =)

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=denitro%40hotmail%2ecom&no_shipping=0&no_note=1&tax=0&currency_code=USD&bn=PP%2dDonationsBF&charset=UTF%2d8

Thanks =)

---------------------------------------------------------------------------------------------
CONTROLS:

For most game screens:
X  - Select/Accept
/\ - Go Back / Cancel 

Song Select Sreen:
[] - Song Options
LEFT / RIGHT - Change Song Difficulty (some songs may only have 1)
SELECT - Screenshot

Main Game:
UP / DOWN / LEFT / RIGHT are used in conjunction with /\ / X / [] / O to hit arrows
Hold R-TRIGGER to exit a song back to the song select screen

---------------------------------------------------------------------------------------------
Version History:
11/28/06 - 0.3a
    -Fixed problem loading songs created with Dancing Monkeys/Gorilla (Causing Crash)
    -Fixed rare (but repeatable) crash when Dizzy mod was enabled
    -Fixed preview music not at right position in VBR encoded songs
    -Fixed preview music playing only playing first 2 seconds of some songs
    -Fixed arrow colors shifting off during some songs
    -Fixed error when the PSP comes back from being suspended during gameplay
    -Fixed rare case of a single step being read out of order
    -Added support for #DISPLAYBPM tag in .SM files
        
11/22/06 - 0.3
(NEW/CHANGED)
    -Added 2 "Hide" mods in song option screen - Dark and Blind
    -Added 1 "Effects" mod in song options screen - Dizzy
    -Added support for dynamic background changes read from .SM files with option to toggle on and off
    -Step hit detection now based on a timing window that is consistent across all BPM ranges
    -Set timing windows on step hits set to be identical to In the Groove (which is very close to StepMania Judge 4)    
    -Added .GIF and .BMP file support
    -Added song background scaling options and sampling modes into system options screen    
    -Song select screen now shows a song's lowest and highest BPM speed
    -New grading and scoring system based off of DDR MAX 2
    -Score Screen Redesigned
    -Song Preview Music now plays proper section of a song instead of from the beginning
    -Added a slight delay to preview playback for a better feel when selecting songs
    -Combined the top arrow base file with the top arrow file to save a draw each frame
    -Song background images now scale to fit the PSP screen by default
    -Max song image size supported increased to 1024x768+    
    -Changed logic for main menu music playback when selecting themes
    -Screenshots now saved as .JPG's to the PSP's photo folder (1.5 firmware doesn't show .PNG's)
    -Top arrow animation changed to flash at 1/4th the songs current bpm, and step animation frames sync to match
    -Changed song loading so that .SM file is preferred over .DWI file and will always be used first if available
    -Normalized difficulty text to be consistent using Beginner, Easy, Medium, Hard, Challenge, and Other
    -Improved in game score display to be animated and always display 9 digits
    -Song and pack lists are now sorted alphabetically
    -Added a noise-shaping and dithering algorithm to mp3 playback for increased audio accuracy
    -New step explosion effects that are now colored to match type of hit
    -Added an option for a delay to exit a song with the R-trigger (2 seconds by Default)
    -Added theme metrics support for more game customization. See the instructions.txt in the theme folder.
    -Song and Pack names that are too long to display will now scroll
    -Added 3 new arrow colors and better separated step colors by where in the current beat the step falls
    -Up and Down on D-pad may now be held for fast scrolling of pack and song lists
    -Current theme selection and CPU speed are now saved and reloaded when restarting the game    
	-Improved resource handling to maintain a higher amount of free linear memory space
    -Greatly receded memory usage of step and beat information when a song is loaded to play
    -Significantly decreased game and song load times

(FIX)
     -Improved syncing for a few songs which were still off, such as a few in the DDR 8th mix pack
     -Fixed a bug that caused a rare sound glitch in the beginning of certain song files
     -Fixed themes loading of custom sound effect (.wav) files
     -Fixed bug(?) in libTremor that was causing slight instabilities due to an ~7KB memory leak on song changes (OGG library)
     -Correct theme is highlighted when entering/re-entering the theme change menu
     -Fixed banner support for jpegs
     -Changed screenshot logic to prevent cases of overwriting older screenshots
     -SMANIAC(SM) and Challange(DWI) steps feet color set to purple
     -Freezes and and BPM changes no longer cause sync issues in songs
     -MP3 and OGG audio that is not encoded at 44.1 kHz is now resampled to play correctly
     -Fixed playback of 1 channel (Mono) OGG song files
     -Fixed bug that caused speed mods to loose accuracy
     -Fixed instabilities when running with an eLoader
      
7/04/06 - 0.2

(NEW)
    -Added theme support for loading custom graphics
    -Added an options menu to the song select screen (accessable by pressing SQUARE)
    -Arrow Speed Modifiers available in the song options menu (see above)
    -Preliminary support for song Freezes (Like in Sandstorm)
    -OGG Music files are now supported
    -JPG Background files are now supported
    -Beginner "feet" color added
    -Music preview plays for selected song at song select screen
    -Marathon songs are now supported
    -Letter grades are now awarded at the song score screen


(CHANGE)
    -Song difficulty selection is now sorted easiest(left) to hardest(right)
    -Holds are now active a little longer after button release
    -Song select screen now scrolls the list with more than 18 entries
    -Missed steps now are now counted as soon as they go out of "boo" range
    -Combo numbers are now outlined for more definition
    -Top arrows are lit up to match the song's beat
    -Game now runs at the default CPU speed (222mhz) (reduces battery ussage)
    -Graphics mode now 32-bit
    -Combo counter during gameplay now displays up to 4 digits
    -Putting the PSP into suspend mode during a song will reutrn game to main menu when resumed
    -MP3's (along with OGG's) are now streamed from the Memory Stick during play 
    -Speed improvement when flipping through song lists
    -Much improved error handeling throughout the game
    -Support for a wider veriaty of song banners (will rotate/resize them into place)

(FIX)
    -Increased Song Compatibility 
    -Changed how some song's are synced
    -Arrow's should no longer "drift" slightly out of sync during the duration of a song
    -Fixed reading of interlaced PNG files which would previously crash song select screen
    -Fixed rare cases of broken hold notes
    -Fixed rare case of songs missing the first couple of steps    
    -Fixed bug where holds very close to a step on same column being hit with the step hit
    -Fixed missing difficulty text during game and score screen
    -Pressing several buttons at once no longer crashes song select screen    
    -No longer need to change the folder name for v2.0+ Eboot Loaders
    -Fixed a small memory leak which could cause crashes after numerous songs are played.
    -Fixed a bug where arrows would stop comming up during gameplay    
    -Other minor bug fixes 
  
	
11/18/05 - 0.1
    First Public Release
    
---------------------------------------------------------------------------------------------
Big Thanks to,
    All the people who contribute to and maintain the the PSPSDK project and it's libraries
    at ps2dev.org, and the whole psp homebrew community in general,
    and the creators of StepMania for making an awesome game =)
    
	"Plaguemix Series" songs are by Plaguefox (www.gamecast.org) and were downloaded
	directly off the songs section on www.stepmania.com

	"Dancing WipEout" songs are by W1p3out and
	downloaded from (http://ddrmulhouse.free.fr/W1p3out_simfiles/Dancing_WipEout_v2_0.html)

I would also like to thank the following people who helped out by submitting feedback about
features and bugs towards version 0.3:
     Christian Betz(Genki_Monkey), ZFB8, Renpatsu, mEo, AJB2K3, Whitehawk, Mysticales, 
     Drake111, *Ollie*, Madridi4ever, Moosecakes ,Sewerhobo, and David12795
---------------------------------------------------------------------------------------------
	
Coding: Babak Delkhoon "DeNitro" (DeNitro@hotmail.com)
Graphics: Matt Sachse "Devin923" (Devin923@hotmail.com) 
	
Have Fun!