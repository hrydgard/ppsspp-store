Webfest
~~~~~~~

Alpha version (incomplete) for GBAX 2007, June/July 2007.

Webfest is a game based on Tempest, and is meant as an example for E3D cross-platform 3D Scene library. It was also supposed to be a testbed for different gameplay ideas for "tunnel shooter" type games, but as you will see, Webfest is only slightly different from Tempest because I have run out of time to experiment with my other gamepay ideas.

It has only been tested on my PSP with 3.02 OE-B custom firmware.

Install by copying the webfest folder to  /PSP/GAME150 on your PSP. (Other destinations might work too).

Instructions for playing the game are in manual.txt in the webfest folder.

Webfest is my first demo/game release for the PSP. Hopefully I'll find time to polish it up in the near future.

- James Higgs (aka Jum)


