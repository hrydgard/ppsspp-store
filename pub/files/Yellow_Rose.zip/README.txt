
Fit + Bandwagon present  : Yellow Rose of Texas
                           4k Linux intro for Assembly'03

                           The PSP port. Place "Yellow_Rose" under psp/game
                           and run with 4.01+ M33 (compiled for 3.71). This
                           is a bit improved version with faster framerate
                           a shorter precalc.

Marq/Fit                 : soft synth + system-level programming, PSP port
NF/Bandwagon             : music + visuals

Connect                  : http://www.kameli.net/fit/
                           http://bandwagon.doesntexist.com/
                           http://unixscene.kameli.net/

