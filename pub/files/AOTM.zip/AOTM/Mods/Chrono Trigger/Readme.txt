Chrono Trigger AOTM Mod
By Oblivion Odyssey

This mod is a mod of DeNitro's attack of the mutants.

Thanks to the members of PSPUPDATES forums for their support.

Thanks to http://www.videogamesprites.net for the sprites.

Thanks to http://www.flamingtext.com for the titles.

Thanks to Google Image Search for the backgrounds!

Thanks to http://www.rpgamer.com for the fantastic music.

Visit PSPUPDATES forums to discuss this mod- any feedback is appreciated greatly.

Visit PSPUPDATES for the most recent release of this mod, and of AOTM.

Hope you enjoy it!

Oblivion Odyssey.