This mod is based on DeNitros excellent Attack of The Mutants.
Just drag the unzipped folder into mods (only in v0.4 of AOTM)

New in this version (v0.2)-
New main menu
Improved graphics
Nicer looking game over screen

To Do-
Add my own background music
Add my own sounds

Thanks to DeNitro for creationg AOTM and to King Ling for Beta Testing

MikDaSpik 3/11/05