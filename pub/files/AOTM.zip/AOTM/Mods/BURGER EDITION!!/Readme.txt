Here is my first mod for the greatest homebrew game on the PSP, Attack of the Mutants.

Be sure to download the latest version of Denitro's AOTM_v0.4 then drop this entire folder into the Mods folder.

Boot the game and then go to load mod.  Voila!  Enjoy!!

Credits:
Overall theme and mod design by xxxdvlman
Title and background pics provided by the Hubble telescope
BG Music "The force (star wars remix)" composed by Sean Sindahl
Core AOTM game and most credit to Denitro.  Thanks for the wonderful game!!

Look for more mods by xxxdvlman in the future!!

Shout out to all over at pspupdates.com

Peace
xxxdvlman