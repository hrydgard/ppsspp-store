
(c) GEARDOME 2007.  www.geardome.com

******************************************************************************

OZONE Freeware License Agreement

******************************************************************************

This Software Licensing Agreement is a legal agreement between GEARDOME and you. By installing this software, by loading or running the Software, by placing or copying the Software onto your hard drive and/or PSP, or by distributing the Software, you agree to be bound by the terms of this Agreement. These are the only terms by which GEARDOME permits copying or use.

1) The Software licensed under this agreement is the PSP videogame OZONE, which consists of executable files, data files, and documentation.

1) THIS SOFTWARE is provided 'as-is', and without any expressed or implied warranty, including and not limited to any implied warranty of merchantability and fitness for a particular purpose. In no event will the author(s) be held liable for any damages arising from the use of this software.

2) By accepting this Agreement, you acknowledge that GEARDOME is the owner of all intellectual property rights in and to THIS SOFTWARE including copyright, trademark, patent, trade secret and all other proprietary rights that are existing throughout the world. 

3) You represent and warrant that you will not violate any of the requirements of this Agreement and further represent and warrant that:

- You will not, and will not permit others to, reverse engineer, decompile, disassemble, derive the source code of, modify, or create derivative works from THIS SOFTWARE.
- You will not sell or transfer reproductions of THIS SOFTWARE or rent, lease, or license THIS SOFTWARE to other parties.
- You will not commercially exploit THIS SOFTWARE in whole or in part such as at any location-based entertainment site or computer gaming center.

4) The origin of THIS SOFTWARE must not be misrepresented; you must not claim that you wrote the original software.

5) You may distribute THIS SOFTWARE for free on any medium, provided this Readme and all associated copyright notices and disclaimers are left intact.

6) GEARDOME reserves the right to modify or amend this Agreement at any time and for any reason or for no reason at all, in their sole discretion, without notice. Please review the version of this Agreement at http://www.geardome.com/ozone_license.txt from time to time in order to keep current with its terms and conditions.

7) This Agreement is terminable at will by you or by GEARDOME for any reason or for no reason at all, in either your or GEARDOME's sole discretion. This Agreement shall terminate immediately upon any breach by you. Upon termination, you agree to discard all copies of THIS SOFTWARE. All provisions of this Agreement which by their nature extend beyond termination remain in effect until fulfilled and apply to respective successors and assigns. 

8) You acknowledge that you have read this License, understand them, and agree to be bound by their terms and conditions.

******************************************************************************

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The Geardome Team are:

 - Nacho S�nchez 
 - C�sar Sampedro 
 - David Garc�a


Greetings goes to:

 - Gorka Su�rez
 - David S�nchez
 - Ken Mowery

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

VISIT US!!


CESAR SAMPEDRO, DIGITAL ARTIST: http://www.cesarsampedro.com

KEN MOWERY, MUSIC PRODUCER: http://www.creatorsweb.com/kenmowery

GORKA SUAREZ: http://perso.wanadoo.es/lessman/


DOWNLOAD MORE GAMES AT: http://www.geardome.com

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~